


package com.mycompany.chatapppart1;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    private Message message1;
    private Message message2;

    @Before
    public void setUp() {

        message1 = new Message(
                1,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        message2 = new Message(
                2,
                "08575975889",
                "Hi Keegan, did you receive the payment?"
        );
    }

    // =========================
    // MESSAGE LENGTH TESTS
    // =========================

    @Test
    public void testCheckMessageLength_validMessage_returnsSuccess() {

        String result = message1.checkMessageLength(
                "Hello there"
        );

        assertEquals(
                "username succesfully captured",
                result
        );
    }

    @Test
    public void testCheckMessageLength_over250chars_returnsFailureWithCount() {

        String longMessage = "a".repeat(260);

        String result = message1.checkMessageLength(longMessage);

        assertEquals(
                "message exceeds 250 characters by 10; please reduce the size",
                result
        );
    }

    @Test
    public void testCheckMessageLength_exactlyAtLimit_returnsSuccess() {

        String text = "a".repeat(250);

        String result = message1.checkMessageLength(text);

        assertEquals(
                "username succesfully captured",
                result
        );
    }

    @Test
    public void testCheckMessageLength_oneOver_returnsFailureWithCountOf1() {

        String text = "a".repeat(251);

        String result = message1.checkMessageLength(text);

        assertEquals(
                "message exceeds 250 characters by 1; please"
                        
public String getMessageID() {
    return messageID;
}

public String getMessageHash() {
    return messageHash;
}

public String getRecipient() {
    return recipient;
}

public String getMessageText() {
    return messageText;
}

@Test
public void testCheckMessageLength_validMessage_returnsSuccess() {

    // ARRANGE
    String text = "Hello";

    // ACT
    String result = message1.checkMessageLength(text);

    // ASSERT
    assertEquals("username succesfully captured", result);
}

@Before
public void setUp() {

    message1 = new Message(
            1,
            "+27718693002",
            "Hi Mike, can you join us for dinner tonight?"
    );

    message2 = new Message(
            2,
            "08575975889",
            "Hi Keegan, did you receive the payment?"
    );
}

These are the exact POE values.

5. Start with Easy Tests First

Do these first:

Test 1 — Valid Message Length
@Test
public void testCheckMessageLength_validMessage_returnsSuccess() {

    String result = message1.checkMessageLength("Hello");

    assertEquals(
            "username succesfully captured",
            result
    );
}
Test 2 — Invalid Message Length
@Test
public void testCheckMessageLength_over250chars_returnsFailureWithCount() {

    String longText = "a".repeat(260);

    String result = message1.checkMessageLength(longText);

    assertEquals(
            "message exceeds 250 characters by 10; please reduce the size",
            result
    );
}
Test 3 — Valid Cell Number
@Test
public void testCheckRecipientCell_validNumber_returnsSuccess() {

    String result = message1.checkRecipientCell("+27718693002");

    assertEquals(
            "cellphone number sccesfully added",
            result
    );
}
Test 4 — Invalid Cell Number
@Test
public void testCheckRecipientCell_invalidNumber_returnsFailure() {

    String result = message2.checkRecipientCell("08575975889");

    assertEquals(
            "cellphone number incorectly formatted or does not contain international code",
            result
    );
}
6. Hash Tests

Your lecturer specifically says:

DO NOT test the full hash because the ID is random.

Instead test the ending.

Your message:

Hi Mike, can you join us for dinner tonight?

First word:

Hi

Last word:

tonight?

Your hash should end with:

:HITONIGHT?

Test:

@Test
public void testCreateMessageHash_correctFormat_endsWithExpectedWords() {

    String hash = message1.createMessageHash();

    assertTrue(
            hash.endsWith(":1:HITONIGHT?")
    );
}
7. Message ID Tests
Check ID exists
@Test
public void testCheckMessageID_generatedID_isNotNull() {

    assertNotNull(message1.getMessageID());
}
Check ID length
@Test
public void testCheckMessageID_generatedID_isExactly10Chars() {

    assertTrue(message1.checkMesssageID());
}
8. Why Your sentMessage() Is Hard to Test

Your lecturer explains that console input (Scanner) makes testing difficult.

Your method:

Scanner sent = new Scanner(System.in);

requires typing during the test.

That’s why lecturers usually want a helper class or a rewritten method.

A simpler approach is:

public String sentMessage(int option)

instead of using Scanner.

Example:

public String sentMessage(int option) {

    switch(option) {

        case 1:
            return "Message successfully sent.";

        case 2:
            return "Press 0 to delete the message.";

        case 3:
            return "Message successfully stored.";

        default:
            return "Invalid option";
    }
}

Then testing becomes easy:

@Test
public void testSentMessage_userSelectsSend_returnsCorrectString() {

    String result = message1.sentMessage(1);

    assertEquals(
            "Message successfully sent.",
            result
    );
}

This is MUCH cleaner for JUnit.

9. Run Your Tests

According to the guide:

Run all tests

Right-click project → Test

Run only MessageTest

Right-click MessageTest.java → Test File

10. Most Important Tip

Fix ONE red test at a time.

The guide specifically says this.

Don’t try fixing everything together;

Start with:

checkMessageLength()
checkRecipientCell()
checkMessageID()
createMessageHash()
sentMessage()

That order is easiest.

@Test
public void testCheckMessageLength_validMessage_returnsSuccess() {

    String result = message1.checkMessageLength("Hello");

    assertEquals(
            "username succesfully captured",
            result
    );
}
// this code invalid message test
@Test
public void testCheckMessageLength_over250chars_returnsFailureWithCount() {

    String longText = "a".repeat(260);

    String result = message1.checkMessageLength(longText);

    assertEquals(
            "message exceeds 250 characters by 10; please reduce the size",
            result
    );
}